-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 16, 2026 at 09:38 AM
-- Server version: 10.6.25-MariaDB-log
-- PHP Version: 8.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trueno27_salama`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `auth_group`
--

INSERT INTO `auth_group` (`id`, `name`) VALUES
(1, 'Gestor'),
(2, 'Operador');

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$260000$WRUpKtyPqQw8nH0Q6jkCDM$GIbD8ouFBHc6/fcbCl8slYW7wA4ah7g3subC9MlDjvk=', '2025-11-28 09:00:52.651617', 1, 'valdimiro', '', '', 'valdimiroeinstein@gmail.com', 1, 1, '2025-11-24 07:34:59.297745'),
(2, 'pbkdf2_sha256$600000$iwQYXr7MK12LoTkzlmtLB5$n49hJpYFVFIEmuo+IaeIcPIMIWPHgxt7jfvnqDYexjg=', '2025-11-26 19:41:38.348985', 0, 'nataniel', 'Nataniel', 'Mandlate', 'Natanielmandlate@gmail.com', 1, 1, '2025-11-26 09:07:41.326692'),
(3, 'pbkdf2_sha256$260000$khyHKqXlOcxu6wCSbnvTgK$RhfHWRD5f9Jp/rlagZEX1MmfQle4bxUmX71HupL1GGQ=', '2025-11-28 06:43:10.618760', 0, 'justino', 'Justino', 'Matlombe', 'justinomatlombe5@gmail.com', 1, 1, '2025-11-26 09:09:10.535319'),
(4, 'pbkdf2_sha256$600000$OIJ96oSaWGJBLn62vYF4Oi$YhO21D4ADrZmfsJKuh6tm8LctxBlwwJB0lhCwxVt/Is=', NULL, 0, 'feliz', 'Feliz', 'Tivane', 'feliztivane@gmail.com', 1, 1, '2025-11-26 18:41:19.465694');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `auth_user_groups`
--

INSERT INTO `auth_user_groups` (`id`, `user_id`, `group_id`) VALUES
(2, 1, 1),
(3, 2, 1),
(4, 3, 1),
(5, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2025-11-26 08:43:26.195287', '1', 'Gestor', 1, '[{\"added\": {}}]', 3, 1),
(2, '2025-11-26 08:43:37.243657', '2', 'Operador', 1, '[{\"added\": {}}]', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2025-11-24 07:09:46.118371'),
(2, 'auth', '0001_initial', '2025-11-24 07:09:46.492841'),
(3, 'admin', '0001_initial', '2025-11-24 07:09:46.581916'),
(4, 'admin', '0002_logentry_remove_auto_add', '2025-11-24 07:09:46.587128'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2025-11-24 07:09:46.593059'),
(6, 'contenttypes', '0002_remove_content_type_name', '2025-11-24 07:09:46.639052'),
(7, 'auth', '0002_alter_permission_name_max_length', '2025-11-24 07:09:46.684279'),
(8, 'auth', '0003_alter_user_email_max_length', '2025-11-24 07:09:46.696390'),
(9, 'auth', '0004_alter_user_username_opts', '2025-11-24 07:09:46.701940'),
(10, 'auth', '0005_alter_user_last_login_null', '2025-11-24 07:09:46.761038'),
(11, 'auth', '0006_require_contenttypes_0002', '2025-11-24 07:09:46.764041'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2025-11-24 07:09:46.780198'),
(13, 'auth', '0008_alter_user_username_max_length', '2025-11-24 07:09:46.789675'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2025-11-24 07:09:46.800226'),
(15, 'auth', '0010_alter_group_name_max_length', '2025-11-24 07:09:46.810403'),
(16, 'auth', '0011_update_proxy_permissions', '2025-11-24 07:09:46.817449'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2025-11-24 07:09:46.828032'),
(18, 'sessions', '0001_initial', '2025-11-24 07:09:46.857155');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('24lxfq7t96iq8u92ifujtfkol5v3u95j', '.eJxVjEsOwiAUAO_C2hBo-bp03zOQB48nVQNJaVfGuxuSLnQ7M5k3C3DsJRw9b2FFdmWSXX5ZhPTMdQh8QL03nlrdtzXykfDTdr40zK_b2f4NCvQytiJaYzSI7B1ZKZxRcfYJCQ0RuKQdWkLyMMtJAaI0UuBkhdHeKSWJfb7inDex:1vOV2k:YdUBkvG8LhlBCP2xjmjdOz_KX_7kh_iG6xx4BBlGQNM', '2025-12-11 05:59:50.816171'),
('5k4xw2xoz51euhvr1rbwkzbcxkyd1q34', '.eJxVjEsOwiAUAO_C2hBo-bp03zOQB48nVQNJaVfGuxuSLnQ7M5k3C3DsJRw9b2FFdmWSXX5ZhPTMdQh8QL03nlrdtzXykfDTdr40zK_b2f4NCvQytiJaYzSI7B1ZKZxRcfYJCQ0RuKQdWkLyMMtJAaI0UuBkhdHeKSWJfb7inDex:1vNR6M:KYnWyr0DsV8HSe92qiu77RFv72wz0VmFvEhrgA9cO6E', '2025-12-08 07:35:10.757433'),
('7q6tzde39bc5fvewnvu11eubyua0tm8t', '.eJxVjDsOwjAQBe_iGln-bhxK-pzBWnvXOIBiKU4qxN1RpBTQvpl5bxFx32rcO69xJnEVWlx-t4T5ycsB6IHLvcnclm2dkzwUedIup0b8up3u30HFXo86BK9BDcp5NZY8GEaXtceQgAA85IKUYLDOacN2tKPJVLxK2hQiZhCfL8thN9Y:1vOYRM:6VTSs3eLUf0UMsKBJdetCqRsnqpcCs2Q746oD0HQMAI', '2025-12-11 09:37:28.333800'),
('7svstz77zvaeiq41ka44r029xjfq5lel', '.eJxVjDsOwjAQBe_iGln-bhxK-pzBWnvXOIBiKU4qxN1RpBTQvpl5bxFx32rcO69xJnEVWlx-t4T5ycsB6IHLvcnclm2dkzwUedIup0b8up3u30HFXo86BK9BDcp5NZY8GEaXtceQgAA85IKUYLDOacN2tKPJVLxK2hQiZhCfL8thN9Y:1vOuLU:vtcpk02u2ZmR1mcxUAWok_IrLATJj2Kos2ysqRhPNCs', '2025-12-12 09:00:52.654840'),
('g4trtabg5ohtoi6ytk8jzraacuj452hq', '.eJxVjEsOwiAUAO_C2hBo-bp03zOQB48nVQNJaVfGuxuSLnQ7M5k3C3DsJRw9b2FFdmWSXX5ZhPTMdQh8QL03nlrdtzXykfDTdr40zK_b2f4NCvQytiJaYzSI7B1ZKZxRcfYJCQ0RuKQdWkLyMMtJAaI0UuBkhdHeKSWJfb7inDex:1vOAvY:6K2UKyn7XSJi-ygcBW57l9nrfxFCz36AA_kJPy9_sD4', '2025-12-10 08:31:04.666269'),
('hru2pbc53hk5v7jb2y6uy3wlk7p09kyi', '.eJxVjEEOwiAQRe_C2hAKFhiX7nsGMgyDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwJ3ERWpx-t4j04LqDdMd6a5JaXZc5yl2RB-1yaomf18P9OyjYy7dGlxTAQDZjtt5FlxXTGEdMoL2ymtEN0RNkbRU5489gFFvjSScLhrN4fwDwlzfu:1vOBVb:Xga4X0AlbNxf7PO7Buh7apBPLgWzPMvupGSJySSwaFk', '2025-12-10 09:08:19.097298'),
('rgxel4m24g1mhtoutg88wagg702ot6oh', '.eJxVjDsOwyAQBe9CHSH-hpTpfQa0LEtwEmHJ2FWUu0dILpL2zcx7swjHXuPRaYtLZlem2eV3S4BPagPkB7T7ynFt-7YkPhR-0s7nNdPrdrp_BxV6HbWatEiSoBSXAwF46bAY670MZQJVLAafdQhIpBOhgayEl8Iqa5SzyD5fA3o4Pw:1vOsCE:4nkdq6ZYReKq539NUZFRP5ZXMzGujmlABKvhmL2Av-o', '2025-12-12 06:43:10.622374'),
('v88z4spv2yv2hoz11xinff34bti5hsa8', '.eJxVjDsOwyAQBe9CHSH-hpTpfQa0LEtwEmHJ2FWUu0dILpL2zcx7swjHXuPRaYtLZlem2eV3S4BPagPkB7T7ynFt-7YkPhR-0s7nNdPrdrp_BxV6HbWatEiSoBSXAwF46bAY670MZQJVLAafdQhIpBOhgayEl8Iqa5SzyD5fA3o4Pw:1vOgVc:z5ifjzz_y_g5HgYkNpaZx8J3Y5HQZsheDSc2R5jIhyU', '2025-12-11 18:14:24.074610'),
('z2oe25ptk94a1q038y69dacszfss4h4y', '.eJxVjDsOwjAQBe_iGln-bhxK-pzBWnvXOIBiKU4qxN1RpBTQvpl5bxFx32rcO69xJnEVWlx-t4T5ycsB6IHLvcnclm2dkzwUedIup0b8up3u30HFXo86BK9BDcp5NZY8GEaXtceQgAA85IKUYLDOacN2tKPJVLxK2hQiZhCfL8thN9Y:1vOYTJ:6wYzuWmvXdVoblKg39dLwgV_R8iSBEz7q46Ur4CzKc8', '2025-12-11 09:39:29.035017');

-- --------------------------------------------------------

--
-- Table structure for table `sl_account_types`
--

CREATE TABLE `sl_account_types` (
  `id` bigint(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_account_types`
--

INSERT INTO `sl_account_types` (`id`, `category`, `name`, `is_active`) VALUES
(1, 'mobile', 'M-Pesa', 1),
(2, 'mobile', 'E-Mola', 1),
(3, 'bank', 'Millennium BIM', 1),
(4, 'cash', 'Cash', 1),
(5, 'mobile', 'M-Cell M-Kesh', 0),
(6, 'bank', 'Nedbank', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sl_client_accounts`
--

CREATE TABLE `sl_client_accounts` (
  `id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `account_type_id` bigint(20) NOT NULL,
  `account_identifier` varchar(100) NOT NULL,
  `balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_client_accounts`
--

INSERT INTO `sl_client_accounts` (`id`, `member_id`, `account_type_id`, `account_identifier`, `balance`, `is_active`) VALUES
(1, 1, 1, '849903381', 0.00, 1),
(2, 2, 2, '870287714', 0.00, 1),
(3, 5, 1, '850049929', 0.00, 0),
(4, 6, 1, '850398817', 0.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sl_company_accounts`
--

CREATE TABLE `sl_company_accounts` (
  `id` bigint(20) NOT NULL,
  `account_type_id` bigint(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `account_identifier` varchar(100) NOT NULL,
  `balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_company_accounts`
--

INSERT INTO `sl_company_accounts` (`id`, `account_type_id`, `name`, `account_identifier`, `balance`, `is_active`) VALUES
(1, 3, 'CONTA BCI MZN - Salama', '142833302', 13903.00, 1),
(2, 1, 'CONTA M-Pesa', '840297715', 39000.00, 1),
(3, 4, 'Caixa', 'Caixa', 24200.00, 1),
(4, 6, 'Nedbank Corp - Salama', '1110293546', 50000.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sl_expenses`
--

CREATE TABLE `sl_expenses` (
  `id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) NOT NULL,
  `expense_date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_expenses`
--

INSERT INTO `sl_expenses` (`id`, `category_id`, `company_account_id`, `expense_date`, `description`, `amount`, `attachment`, `is_active`, `created_by_id`, `created_at`) VALUES
(1, 1, 2, '2025-11-24', 'Energia para o escritorio', 200.00, 'expenses/2025/11/runillust.png', 1, NULL, '2025-11-24 11:32:12'),
(2, 5, 3, '2025-11-24', 'Combustivel Diario Ractis ALX 831MC', 2000.00, 'expenses/2025/11/BioVision_Newsletter_August_2025.pdf', 1, NULL, '2025-11-24 11:40:34'),
(3, 3, 3, '2025-11-24', 'Almoço, doze de frango', 300.00, 'expenses/2025/11/Run_3.png', 1, NULL, '2025-11-24 12:32:13'),
(4, 5, 2, '2025-11-26', 'Abastecimento para Lamborghini', 55000.00, 'expenses/2025/11/256-QUOTE1-FUUTA_DJALOO_MULTI_SERVICES_SU_LDA-20251030_1.jpg', 1, NULL, '2025-11-26 18:55:06'),
(5, 1, 3, '2025-11-27', 'Energia do escritorio', 200.00, '', 1, 1, '2025-11-27 08:28:28');

-- --------------------------------------------------------

--
-- Table structure for table `sl_expense_categories`
--

CREATE TABLE `sl_expense_categories` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_expense_categories`
--

INSERT INTO `sl_expense_categories` (`id`, `name`, `description`, `is_active`) VALUES
(1, 'Credelec', 'Energia Electrica', 1),
(2, 'Transporte', 'Transporte', 0),
(3, 'Ajuda de Custos', NULL, 1),
(4, 'Credito e Internet', NULL, 1),
(5, 'Combustivel', 'Combustivel', 1),
(6, 'Manutençao e Reparaçao', 'ffg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sl_incomes`
--

CREATE TABLE `sl_incomes` (
  `id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) NOT NULL,
  `income_date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_incomes`
--

INSERT INTO `sl_incomes` (`id`, `category_id`, `company_account_id`, `income_date`, `description`, `amount`, `attachment`, `is_active`, `created_by_id`, `created_at`) VALUES
(1, 5, 2, '2025-11-24', 'Deposito', 200.00, NULL, 1, NULL, '2025-11-24 12:08:44'),
(2, 5, 1, '2025-11-24', 'Deposito', 1903.00, 'incomes/2025/11/GymRules.pdf', 1, NULL, '2025-11-24 12:15:48'),
(3, 2, 1, '2025-11-24', 'Garantias', 500.00, 'incomes/2025/11/WatrSign.pdf', 1, NULL, '2025-11-24 12:33:23'),
(4, 5, 2, '2025-11-26', 'Boost ao Business', 50000.00, 'incomes/2025/11/256-PROINV-FUUTA_DJALOO_MULTI_SERVICES_SU_LDA-20251030_1.jpg', 1, NULL, '2025-11-26 19:02:30'),
(5, 5, 3, '2025-11-27', 'Canalizaçao', 2000.00, '', 1, 1, '2025-11-27 08:32:40');

-- --------------------------------------------------------

--
-- Table structure for table `sl_income_categories`
--

CREATE TABLE `sl_income_categories` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_income_categories`
--

INSERT INTO `sl_income_categories` (`id`, `name`, `description`, `is_active`) VALUES
(1, 'Rendimentos Diversos', 'Rendimentos Diversos', 1),
(2, 'Pagamento de Garantias', 'Pagamento de Garantias', 1),
(3, 'Venda de Material', 'Venda de Material', 1),
(4, 'Taxa Administrativa', 'Taxas Administrativa', 1),
(5, 'Depósitos / Entradas Directas', 'Depósitos / Entradas Directas', 1),
(6, 'Gift', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sl_interest_types`
--

CREATE TABLE `sl_interest_types` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `rate` decimal(7,4) NOT NULL,
  `period_type` varchar(10) NOT NULL,
  `calculation_method` varchar(20) NOT NULL DEFAULT 'flat',
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_interest_types`
--

INSERT INTO `sl_interest_types` (`id`, `name`, `description`, `rate`, `period_type`, `calculation_method`, `is_active`) VALUES
(1, 'Taxa Fixa - 30%', '30% ao mÊs sobre o saldo', 30.0000, 'monthly', 'flat', 1),
(2, 'VIP', '28', 28.0000, 'monthly', 'flat', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sl_leased_vehicles`
--

CREATE TABLE `sl_leased_vehicles` (
  `id` bigint(20) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `chassis_number` varchar(100) DEFAULT NULL,
  `acquisition_cost` decimal(15,2) DEFAULT NULL,
  `weekly_rent_default` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) NOT NULL DEFAULT 'available',
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_leased_vehicles`
--

INSERT INTO `sl_leased_vehicles` (`id`, `plate_number`, `brand`, `model`, `year`, `chassis_number`, `acquisition_cost`, `weekly_rent_default`, `status`, `notes`) VALUES
(1, 'AFV  208 MC', 'TVS', 'King Delux', 2016, 'DGFDGD', 150000.00, 2500.00, 'leased', NULL),
(2, 'ALX 330 MC', 'Toyota', 'Hiace', 2004, 'SSSKMFSD', 450000.00, 3500.00, 'available', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sl_loans`
--

CREATE TABLE `sl_loans` (
  `id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `loan_type_id` bigint(20) DEFAULT NULL,
  `interest_type_id` bigint(20) NOT NULL,
  `principal_amount` decimal(15,2) NOT NULL,
  `term_periods` int(11) NOT NULL,
  `period_type` varchar(10) NOT NULL DEFAULT 'monthly',
  `payment_per_period` decimal(15,2) DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `first_payment_date` date DEFAULT NULL,
  `disburse_method` varchar(20) NOT NULL DEFAULT 'cash',
  `company_account_id` bigint(20) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `approved_by_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_loans`
--

INSERT INTO `sl_loans` (`id`, `member_id`, `loan_type_id`, `interest_type_id`, `principal_amount`, `term_periods`, `period_type`, `payment_per_period`, `release_date`, `first_payment_date`, `disburse_method`, `company_account_id`, `purpose`, `attachment`, `remarks`, `status`, `created_at`, `created_by_id`, `approved_by_id`) VALUES
(1, 2, 1, 1, 10000.00, 1, 'monthly', 13000.00, '2025-11-24', '2025-12-24', 'cash', NULL, 'Capital Para pequenos Negocios', 'loans/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_eff9ab48.jpg', NULL, 'active', '2025-11-24 14:56:58', 1, NULL),
(2, 1, 1, 1, 10000.00, 1, 'monthly', 13000.00, '2025-11-24', '2025-12-24', 'cash', NULL, 'Capital Para pequenos Negocios', 'loans/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_eff9ab48_qwiO6eF.jpg', NULL, 'closed', '2025-11-24 16:14:35', 1, NULL),
(3, 3, 1, 1, 10000.00, 1, 'monthly', 13000.00, '2025-11-25', '2025-12-25', 'cash', NULL, 'Capital Para pequenos Negocios', 'loans/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_eff9ab48_o2pRebm.jpg', NULL, 'disbursed', '2025-11-25 11:19:35', 1, NULL),
(4, 2, 1, 1, 5000.00, 1, 'monthly', 6500.00, '2025-11-25', '2025-12-25', 'mobile_wallet', 1, 'Capital Para pequenos Negocios', '', NULL, 'approved', '2025-11-25 11:39:04', 1, NULL),
(5, 1, 1, 1, 3000.00, 1, 'monthly', 3900.00, '2025-11-25', '2025-12-25', 'company_account', 1, 'Capital Para pequenos Negocios', 'loans/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_7d7b0632.jpg', NULL, 'disbursed', '2025-11-25 12:16:32', 1, 1),
(6, 2, 1, 1, 10000.00, 1, 'monthly', 13000.00, '2025-11-25', '2025-12-31', 'cash', NULL, 'Capital Para pequenos Negocios', '', NULL, 'closed', '2025-11-25 14:43:17', 1, 1),
(7, 2, 1, 1, 10000.00, 1, 'monthly', 13000.00, '2025-11-25', '2025-12-25', 'mobile_wallet', 1, 'Capital Para pequenos Negocios', '', NULL, 'closed', '2025-11-25 14:45:49', 1, 1),
(8, 4, 1, 1, 20000.00, 1, 'monthly', 26000.00, '2025-11-26', '2025-12-26', 'mobile_wallet', 2, 'Capital Para pequenos Negocios', 'loans/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_7d7b0632_C20aSv3.jpg', NULL, 'cancelled', '2025-11-26 06:28:50', 1, NULL),
(9, 6, 1, 1, 10000.00, 1, 'monthly', 13000.00, '2025-11-26', '2025-12-26', 'mobile_wallet', 2, 'Capital Para pequenos Negocios', 'loans/2025/11/256-QUOTE1-FUUTA_DJALOO_MULTI_SERVICES_SU_LDA-20251030_1.jpg', 'edsgdfgdf', 'closed', '2025-11-26 19:11:10', 1, 1),
(10, 4, 1, 1, 10000.00, 1, 'monthly', 13000.00, '2025-11-27', '2025-12-31', 'mobile_wallet', 1, 'Capital Para pequenos Negocios', '', NULL, 'pending', '2025-11-27 09:23:44', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sl_loan_disbursements`
--

CREATE TABLE `sl_loan_disbursements` (
  `id` bigint(20) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) NOT NULL,
  `disburse_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `method` varchar(20) NOT NULL DEFAULT 'cash',
  `attachment` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_loan_disbursements`
--

INSERT INTO `sl_loan_disbursements` (`id`, `loan_id`, `member_id`, `company_account_id`, `disburse_date`, `amount`, `method`, `attachment`, `notes`, `created_at`) VALUES
(3, 2, 1, 3, '2025-11-25', 10000.00, 'cash', 'loan_disbursements/2025/11/584771000_1176494473920875_7716780817248368469_n.jpg', NULL, '2025-11-25 11:06:22'),
(4, 3, 3, 1, '2025-11-25', 10000.00, 'cash', 'loan_disbursements/2025/11/584771000_1176494473920875_7716780817248368469_n_QAxFEEE.jpg', NULL, '2025-11-25 11:26:37'),
(5, 5, 1, 1, '2025-11-25', 3000.00, 'cash', '', NULL, '2025-11-25 12:30:28'),
(6, 6, 2, 1, '2025-11-25', 10000.00, 'mobile', '', NULL, '2025-11-25 14:43:49'),
(7, 7, 2, 1, '2025-11-25', 10000.00, 'mobile', '', NULL, '2025-11-25 14:46:20'),
(8, 9, 6, 2, '2025-11-26', 10000.00, 'mobile', '', 'KHKBHHBJSHJFEFD', '2025-11-26 19:14:19');

-- --------------------------------------------------------

--
-- Table structure for table `sl_loan_guarantees`
--

CREATE TABLE `sl_loan_guarantees` (
  `id` bigint(20) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `guarantee_type` varchar(100) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `estimated_price` decimal(15,2) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_loan_guarantees`
--

INSERT INTO `sl_loan_guarantees` (`id`, `loan_id`, `name`, `guarantee_type`, `serial_number`, `estimated_price`, `attachment`, `description`) VALUES
(1, 1, 'Laptop', 'Equipamento', 'DFHRTSHR7776D', 18000.00, 'loan_guarantees/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_eff9ab48.jpg', 'Laptop HP Zebook G6'),
(2, 2, 'Iphone 14', 'Celular', 'KJHJDHDYHUD9978', 30000.00, 'loan_guarantees/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_7d7b0632.jpg', NULL),
(3, 3, 'Garantia', 'Celular', 'GGRGRGSDGD', 40000.00, 'loan_guarantees/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_7d7b0632_cXrp25e.jpg', NULL),
(4, 4, 'Laptop', 'Celular', 'DDDFDSAS', 30000.00, '', NULL),
(5, 9, 'Laptop G6', 'Computador', 'FGFVDGDGGDS', 50000.00, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sl_loan_guarantors`
--

CREATE TABLE `sl_loan_guarantors` (
  `id` bigint(20) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  `guarantor_id` bigint(20) NOT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_loan_guarantors`
--

INSERT INTO `sl_loan_guarantors` (`id`, `loan_id`, `guarantor_id`, `account_number`, `amount`) VALUES
(1, 1, 1, '840297715', 18000.00),
(2, 2, 2, '456665t', 30000.00),
(3, 3, 2, 'regretgh', 30000.00),
(4, 4, 2, '456546', 45000.00);

-- --------------------------------------------------------

--
-- Table structure for table `sl_loan_payment_requests`
--

CREATE TABLE `sl_loan_payment_requests` (
  `id` bigint(20) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) DEFAULT NULL,
  `due_date` date NOT NULL,
  `amount_due` decimal(15,2) NOT NULL,
  `amount_paid` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `paid_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_loan_payment_requests`
--

INSERT INTO `sl_loan_payment_requests` (`id`, `loan_id`, `member_id`, `company_account_id`, `due_date`, `amount_due`, `amount_paid`, `status`, `attachment`, `created_at`, `paid_at`) VALUES
(1, 1, 2, NULL, '2025-12-24', 13000.00, NULL, 'pending', '', '2025-11-24 15:51:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sl_loan_repayments`
--

CREATE TABLE `sl_loan_repayments` (
  `id` bigint(20) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `interest_amount` decimal(15,2) NOT NULL,
  `principal_amount` decimal(15,2) NOT NULL,
  `principal_balance_after` decimal(15,2) NOT NULL,
  `method` varchar(20) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_loan_repayments`
--

INSERT INTO `sl_loan_repayments` (`id`, `loan_id`, `member_id`, `company_account_id`, `payment_date`, `amount`, `interest_amount`, `principal_amount`, `principal_balance_after`, `method`, `attachment`, `notes`, `created_at`) VALUES
(1, 5, 1, 1, '2025-11-25', 1000.00, 900.00, 100.00, 2900.00, 'bank', 'loan_repayments/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_eff9ab48.jpg', NULL, '2025-11-25 13:57:30'),
(2, 2, 1, 2, '2025-11-25', 13000.00, 3000.00, 10000.00, 0.00, 'mobile', 'loan_repayments/2025/11/WhatsApp_Image_2025-09-25_at_07.33.55_7d7b0632.jpg', NULL, '2025-11-25 14:13:42'),
(3, 3, 3, 3, '2025-11-25', 5000.00, 3000.00, 2000.00, 8000.00, 'cash', '', NULL, '2025-11-25 14:17:25'),
(4, 3, 3, 3, '2025-11-25', 2400.00, 2400.00, 0.00, 8000.00, 'cash', '', NULL, '2025-11-25 14:22:54'),
(5, 6, 2, 1, '2025-11-25', 13000.00, 3000.00, 10000.00, 0.00, 'bank', '', NULL, '2025-11-25 14:44:39'),
(6, 7, 2, 1, '2025-11-25', 3000.00, 3000.00, 0.00, 10000.00, 'bank', '', NULL, '2025-11-25 14:46:56'),
(7, 7, 2, 2, '2025-11-25', 5000.00, 0.00, 5000.00, 5000.00, 'mobile', '', NULL, '2025-11-25 14:47:44'),
(8, 7, 2, 2, '2025-11-25', 5000.00, 0.00, 5000.00, 0.00, 'mobile', '', NULL, '2025-11-25 14:48:14'),
(9, 9, 6, 2, '2025-11-26', 5000.00, 3000.00, 2000.00, 8000.00, 'mobile', 'loan_repayments/2025/11/256-QUOTE1-FUUTA_DJALOO_MULTI_SERVICES_SU_LDA-20251030_1.jpg', NULL, '2025-11-26 19:24:45'),
(10, 9, 6, 2, '2025-11-26', 8000.00, 0.00, 8000.00, 0.00, 'mobile', 'loan_repayments/2025/11/256-QUOTE1-FUUTA_DJALOO_MULTI_SERVICES_SU_LDA-20251030_1_jGpAm3o.jpg', NULL, '2025-11-26 19:26:18');

-- --------------------------------------------------------

--
-- Table structure for table `sl_loan_types`
--

CREATE TABLE `sl_loan_types` (
  `id` bigint(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_loan_types`
--

INSERT INTO `sl_loan_types` (`id`, `name`, `description`, `is_active`) VALUES
(1, 'Padrão', 'Emprestimo Padrão', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sl_members`
--

CREATE TABLE `sl_members` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `legal_name` varchar(255) DEFAULT NULL,
  `is_company` tinyint(1) NOT NULL DEFAULT 0,
  `phone` varchar(30) NOT NULL,
  `alt_phone` varchar(30) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `marital_status` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `nuit` varchar(30) DEFAULT NULL,
  `id_type` varchar(50) DEFAULT NULL,
  `id_number` varchar(100) DEFAULT NULL,
  `id_issue_date` date DEFAULT NULL,
  `id_expiry_date` date DEFAULT NULL,
  `kyc_notes` text DEFAULT NULL,
  `manager_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_members`
--

INSERT INTO `sl_members` (`id`, `first_name`, `last_name`, `legal_name`, `is_company`, `phone`, `alt_phone`, `email`, `city`, `address`, `profession`, `marital_status`, `gender`, `nuit`, `id_type`, `id_number`, `id_issue_date`, `id_expiry_date`, `kyc_notes`, `manager_id`, `is_active`) VALUES
(1, 'Telmo', 'Moiane', NULL, 0, '840298815', NULL, 'telmo.muianga@truenorth.co.mz', 'Matola', 'Fomento Casa 34, Q34', 'IT', 'solteiro', 'masculino', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1),
(2, 'Igor', 'Gervasio', 'None', 0, '879038823', 'None', 'igor.gervasio@truenorth.co.mz', 'Matola Santos', 'Fomento Casa 564, Q645', 'IT', 'solteiro', 'masculino', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1),
(3, 'João', 'Nhantumbo', 'Joao Nhantumbo', 0, '840297715', '821510158', 'valdimiro.f.m@gmail.com', 'Maputo', 'Bagamoyo, C36 Q26\r\nBairro Bagamoyo', 'Motoboy', 'solteiro', 'masculino', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1),
(4, 'Levi Vicente', 'Pelembe', 'Levi Vicente Simoes pelembe', 0, '879980023', '840093412', 'levipelembe2013@gmail.com', 'Maputo', 'Mahotas C32, Q26', NULL, 'casado', 'masculino', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1),
(5, 'Maria', 'Paula', 'Maria Ana Paula', 0, '850998827', '873938827', 'maria.ana@gmail.com', 'Beira', 'None', 'Enfermeira', 'solteiro', 'feminino', NULL, 'BI', '234545647F', '2022-06-15', '2027-11-26', NULL, 3, 1),
(6, 'Paulo', 'Macuacua', 'Paulo Pedro Macuacua', 0, '840398817', '870498871', 'paulo.macuacua@gmail.com', 'Beira', 'Maquinono C34 Q773', 'Comerciante', 'casado', 'masculino', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sl_transactions`
--

CREATE TABLE `sl_transactions` (
  `id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) NOT NULL,
  `tx_type` varchar(3) NOT NULL,
  `source_type` varchar(20) DEFAULT NULL,
  `source_id` bigint(20) DEFAULT NULL,
  `tx_date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `balance_before` decimal(15,2) NOT NULL,
  `balance_after` decimal(15,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `created_by_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sl_transactions`
--

INSERT INTO `sl_transactions` (`id`, `company_account_id`, `tx_type`, `source_type`, `source_id`, `tx_date`, `description`, `amount`, `balance_before`, `balance_after`, `is_active`, `created_at`, `created_by_id`) VALUES
(1, 3, 'OUT', 'expense', 3, '2025-11-24', 'Despesa: Almoço, doze de frango', 300.00, 3000.00, 2700.00, 1, '2025-11-24 12:32:13', NULL),
(2, 1, 'IN', 'income', 3, '2025-11-24', 'Rendimento: Garantias', 500.00, 21903.00, 22403.00, 1, '2025-11-24 12:33:23', NULL),
(3, 3, 'OUT', 'manual', NULL, '2025-11-24', 'Ajuste manual de saldo (-700.00)', 700.00, 2700.00, 2000.00, 1, '2025-11-24 12:43:52', NULL),
(4, 3, 'OUT', 'loan_disbursement', 3, '2025-11-25', 'Desembolso de empréstimo (Loan #2) para Telmo Moiane', 10000.00, 2000.00, -8000.00, 1, '2025-11-25 11:06:22', NULL),
(5, 1, 'OUT', 'loan_disbursement', 4, '2025-11-25', 'Desembolso de empréstimo (Loan #3) para João Nhantumbo', 10000.00, 22403.00, 12403.00, 1, '2025-11-25 11:26:37', NULL),
(6, 3, 'IN', 'manual', NULL, '2025-11-25', 'Ajuste manual de saldo (+23000.00)', 23000.00, -8000.00, 15000.00, 1, '2025-11-25 11:28:14', NULL),
(7, 1, 'OUT', 'loan_disbursement', 5, '2025-11-25', 'Desembolso de empréstimo (Loan #5) para Telmo Moiane | Conta cliente: Carteira móvel · M-Pesa (84000989)', 3000.00, 12403.00, 9403.00, 1, '2025-11-25 12:30:28', NULL),
(8, 1, 'IN', 'loan_repayment', 1, '2025-11-25', 'Reembolso de empréstimo (Loan #5) de Telmo Moiane - Juros: 900.00 · Principal: 100.00', 1000.00, 9403.00, 10403.00, 1, '2025-11-25 13:57:30', NULL),
(9, 2, 'IN', 'loan_repayment', 2, '2025-11-25', 'Liquidação total (juros + principal) - Reembolso de empréstimo (Loan #2) de Telmo Moiane - Juros: 3000.00 · Principal: 10000.00', 13000.00, 10000.00, 23000.00, 1, '2025-11-25 14:13:42', NULL),
(10, 3, 'IN', 'loan_repayment', 3, '2025-11-25', 'Pagamento parcial (juros + principal) - Reembolso de empréstimo (Loan #3) de João Nhantumbo - Juros: 3000.00 · Principal: 2000.00', 5000.00, 15000.00, 20000.00, 1, '2025-11-25 14:17:25', NULL),
(11, 3, 'IN', 'loan_repayment', 4, '2025-11-25', 'Pagamento apenas de juros - Reembolso de empréstimo (Loan #3) de João Nhantumbo - Juros: 2400.00 · Principal: 0.00', 2400.00, 20000.00, 22400.00, 1, '2025-11-25 14:22:54', NULL),
(12, 1, 'OUT', 'loan_disbursement', 6, '2025-11-25', 'Desembolso de empréstimo (Loan #6) para Igor Gervasio | Conta cliente: Carteira móvel · E-Mola (870287714)', 10000.00, 10403.00, 403.00, 1, '2025-11-25 14:43:49', NULL),
(13, 1, 'IN', 'loan_repayment', 5, '2025-11-25', 'Liquidação total (juros + principal) - Reembolso de empréstimo (Loan #6) de Igor Gervasio - Juros: 3000.00 · Principal: 10000.00', 13000.00, 403.00, 13403.00, 1, '2025-11-25 14:44:39', NULL),
(14, 1, 'OUT', 'loan_disbursement', 7, '2025-11-25', 'Desembolso de empréstimo (Loan #7) para Igor Gervasio | Conta cliente: Carteira móvel · E-Mola (870287714)', 10000.00, 13403.00, 3403.00, 1, '2025-11-25 14:46:20', NULL),
(15, 1, 'IN', 'loan_repayment', 6, '2025-11-25', 'Pagamento apenas de juros - Reembolso de empréstimo (Loan #7) de Igor Gervasio - Juros: 3000.00 · Principal: 0.00', 3000.00, 3403.00, 6403.00, 1, '2025-11-25 14:46:56', NULL),
(16, 2, 'IN', 'loan_repayment', 7, '2025-11-25', 'Pagamento parcial (juros + principal) - Reembolso de empréstimo (Loan #7) de Igor Gervasio - Juros: 0.00 · Principal: 5000.00', 5000.00, 23000.00, 28000.00, 1, '2025-11-25 14:47:44', NULL),
(17, 2, 'IN', 'loan_repayment', 8, '2025-11-25', 'Pagamento parcial (juros + principal) - Reembolso de empréstimo (Loan #7) de Igor Gervasio - Juros: 0.00 · Principal: 5000.00', 5000.00, 28000.00, 33000.00, 1, '2025-11-25 14:48:14', NULL),
(18, 2, 'IN', 'tuktuk_lease_payment', 4, '2025-11-26', 'Leasing Tuk-Tuk · Contrato #1 · AAL 830 MC', 2500.00, 33000.00, 35500.00, 1, '2025-11-26 06:22:14', NULL),
(19, 1, 'IN', 'tuktuk_lease_payment', 5, '2025-11-26', 'Leasing Txopela · Contrato #1 · AAL 830 MC', 2500.00, 6403.00, 8903.00, 1, '2025-11-26 10:39:26', NULL),
(20, 4, 'IN', 'manual', NULL, '2025-11-26', 'Ajuste manual de saldo (+50000)', 50000.00, 0.00, 50000.00, 1, '2025-11-26 18:48:26', NULL),
(21, 2, 'OUT', 'expense', 4, '2025-11-26', 'Despesa: Abastecimento para Lamborghini', 55000.00, 35500.00, -19500.00, 1, '2025-11-26 18:55:06', NULL),
(22, 2, 'IN', 'income', 4, '2025-11-26', 'Rendimento: Boost ao Business', 50000.00, -19500.00, 30500.00, 1, '2025-11-26 19:02:30', NULL),
(23, 2, 'OUT', 'loan_disbursement', 8, '2025-11-26', 'Desembolso de empréstimo (Loan #9) para Paulo Macuacua | Conta cliente: Carteira móvel · M-Pesa (850398817)', 10000.00, 30500.00, 20500.00, 1, '2025-11-26 19:14:19', NULL),
(24, 2, 'IN', 'loan_repayment', 9, '2025-11-26', 'Pagamento parcial (juros + principal) - Reembolso de empréstimo (Loan #9) de Paulo Macuacua - Juros: 3000.00 · Principal: 2000.00', 5000.00, 20500.00, 25500.00, 1, '2025-11-26 19:24:45', NULL),
(25, 2, 'IN', 'loan_repayment', 10, '2025-11-26', 'Liquidação total (juros + principal) - Reembolso de empréstimo (Loan #9) de Paulo Macuacua - Juros: 0.00 · Principal: 8000.00', 8000.00, 25500.00, 33500.00, 1, '2025-11-26 19:26:18', NULL),
(26, 2, 'IN', 'tuktuk_lease_payment', 6, '2025-11-26', 'Leasing Txopela · Contrato #3 · ALW 887 MC', 3000.00, 33500.00, 36500.00, 1, '2025-11-26 19:34:42', NULL),
(27, 2, 'IN', 'vehicle_lease_paymen', 1, '2025-11-27', 'Leasing Viatura · Contrato #1 · AFV  208 MC', 2500.00, 36500.00, 39000.00, 1, '2025-11-27 07:54:13', NULL),
(28, 1, 'IN', 'vehicle_lease_paymen', 2, '2025-11-27', 'Leasing Viatura · Contrato #1 · AFV  208 MC', 2500.00, 8903.00, 11403.00, 1, '2025-11-27 08:07:52', 1),
(29, 1, 'IN', 'vehicle_lease_paymen', 3, '2025-11-27', 'Leasing Viatura · Contrato #1 · AFV  208 MC', 2500.00, 11403.00, 13903.00, 1, '2025-11-27 08:20:37', 1),
(30, 3, 'OUT', 'expense', 5, '2025-11-27', 'Despesa: Energia do escritorio', 200.00, 22400.00, 22200.00, 1, '2025-11-27 08:28:28', NULL),
(31, 3, 'IN', 'income', 5, '2025-11-27', 'Rendimento: Canalizaçao', 2000.00, 22200.00, 24200.00, 1, '2025-11-27 08:32:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sl_vehicle_lease_contracts`
--

CREATE TABLE `sl_vehicle_lease_contracts` (
  `id` bigint(20) NOT NULL,
  `leased_vehicle_id` bigint(20) NOT NULL,
  `driver_id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `weekly_rent` decimal(15,2) NOT NULL,
  `payment_weekday` smallint(6) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_vehicle_lease_contracts`
--

INSERT INTO `sl_vehicle_lease_contracts` (`id`, `leased_vehicle_id`, `driver_id`, `company_account_id`, `start_date`, `end_date`, `weekly_rent`, `payment_weekday`, `status`, `created_at`, `created_by_id`, `notes`) VALUES
(1, 1, 6, 2, '2025-11-01', NULL, 2500.00, 5, 'active', '2025-11-27 07:53:59', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sl_vehicle_lease_payments`
--

CREATE TABLE `sl_vehicle_lease_payments` (
  `id` bigint(20) NOT NULL,
  `contract_id` bigint(20) NOT NULL,
  `driver_id` bigint(20) NOT NULL,
  `company_account_id` bigint(20) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `method` varchar(20) NOT NULL DEFAULT 'cash',
  `attachment` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sl_vehicle_lease_payments`
--

INSERT INTO `sl_vehicle_lease_payments` (`id`, `contract_id`, `driver_id`, `company_account_id`, `payment_date`, `amount`, `method`, `attachment`, `notes`, `created_by_id`, `created_at`) VALUES
(1, 1, 6, 2, '2025-11-27', 2500.00, 'cash', '', NULL, NULL, '2025-11-27 07:54:13'),
(2, 1, 6, 1, '2025-11-27', 2500.00, 'mobile_wallet', '', NULL, NULL, '2025-11-27 08:07:52'),
(3, 1, 6, 1, '2025-11-27', 2500.00, 'mobile_wallet', '', NULL, 1, '2025-11-27 08:20:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `sl_account_types`
--
ALTER TABLE `sl_account_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sl_client_accounts`
--
ALTER TABLE `sl_client_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_client_accounts_member_fk` (`member_id`),
  ADD KEY `sl_client_accounts_type_fk` (`account_type_id`);

--
-- Indexes for table `sl_company_accounts`
--
ALTER TABLE `sl_company_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_company_accounts_type_fk` (`account_type_id`);

--
-- Indexes for table `sl_expenses`
--
ALTER TABLE `sl_expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_expenses_category_fk` (`category_id`),
  ADD KEY `sl_expenses_company_account_fk` (`company_account_id`),
  ADD KEY `fk_expenses_created_by` (`created_by_id`);

--
-- Indexes for table `sl_expense_categories`
--
ALTER TABLE `sl_expense_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sl_incomes`
--
ALTER TABLE `sl_incomes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_incomes_category_fk` (`category_id`),
  ADD KEY `sl_incomes_company_account_fk` (`company_account_id`),
  ADD KEY `fk_incomes_created_by` (`created_by_id`);

--
-- Indexes for table `sl_income_categories`
--
ALTER TABLE `sl_income_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sl_interest_types`
--
ALTER TABLE `sl_interest_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sl_leased_vehicles`
--
ALTER TABLE `sl_leased_vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plate_number` (`plate_number`);

--
-- Indexes for table `sl_loans`
--
ALTER TABLE `sl_loans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_loans_member_fk` (`member_id`),
  ADD KEY `sl_loans_loan_type_fk` (`loan_type_id`),
  ADD KEY `sl_loans_interest_type_fk` (`interest_type_id`),
  ADD KEY `sl_loans_company_account_fk` (`company_account_id`),
  ADD KEY `idx_sl_loans_approved_by` (`approved_by_id`);

--
-- Indexes for table `sl_loan_disbursements`
--
ALTER TABLE `sl_loan_disbursements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_ld_loan_fk` (`loan_id`),
  ADD KEY `sl_ld_member_fk` (`member_id`),
  ADD KEY `sl_ld_company_account_fk` (`company_account_id`);

--
-- Indexes for table `sl_loan_guarantees`
--
ALTER TABLE `sl_loan_guarantees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_loan_guarantees_loan_fk` (`loan_id`);

--
-- Indexes for table `sl_loan_guarantors`
--
ALTER TABLE `sl_loan_guarantors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_loan_guarantors_loan_fk` (`loan_id`),
  ADD KEY `sl_loan_guarantors_member_fk` (`guarantor_id`);

--
-- Indexes for table `sl_loan_payment_requests`
--
ALTER TABLE `sl_loan_payment_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_lpr_loan_fk` (`loan_id`),
  ADD KEY `sl_lpr_member_fk` (`member_id`),
  ADD KEY `sl_lpr_company_account_fk` (`company_account_id`);

--
-- Indexes for table `sl_loan_repayments`
--
ALTER TABLE `sl_loan_repayments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sl_loan_repayments_loan` (`loan_id`),
  ADD KEY `idx_sl_loan_repayments_member` (`member_id`),
  ADD KEY `idx_sl_loan_repayments_company_account` (`company_account_id`);

--
-- Indexes for table `sl_loan_types`
--
ALTER TABLE `sl_loan_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sl_members`
--
ALTER TABLE `sl_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_members_manager_id_idx` (`manager_id`);

--
-- Indexes for table `sl_transactions`
--
ALTER TABLE `sl_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sl_transactions_company_account_fk` (`company_account_id`),
  ADD KEY `fk_sl_transactions_created_by` (`created_by_id`);

--
-- Indexes for table `sl_vehicle_lease_contracts`
--
ALTER TABLE `sl_vehicle_lease_contracts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_vlc_leased_vehicle` (`leased_vehicle_id`),
  ADD KEY `fk_vlc_driver` (`driver_id`),
  ADD KEY `fk_vlc_company_account` (`company_account_id`),
  ADD KEY `fk_vlc_created_by` (`created_by_id`);

--
-- Indexes for table `sl_vehicle_lease_payments`
--
ALTER TABLE `sl_vehicle_lease_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_vlp_contract` (`contract_id`),
  ADD KEY `fk_vlp_driver` (`driver_id`),
  ADD KEY `fk_vlp_company_account` (`company_account_id`),
  ADD KEY `fk_vlp_created_by` (`created_by_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `sl_account_types`
--
ALTER TABLE `sl_account_types`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sl_client_accounts`
--
ALTER TABLE `sl_client_accounts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sl_company_accounts`
--
ALTER TABLE `sl_company_accounts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sl_expenses`
--
ALTER TABLE `sl_expenses`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sl_expense_categories`
--
ALTER TABLE `sl_expense_categories`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sl_incomes`
--
ALTER TABLE `sl_incomes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sl_income_categories`
--
ALTER TABLE `sl_income_categories`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sl_interest_types`
--
ALTER TABLE `sl_interest_types`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sl_leased_vehicles`
--
ALTER TABLE `sl_leased_vehicles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sl_loans`
--
ALTER TABLE `sl_loans`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sl_loan_disbursements`
--
ALTER TABLE `sl_loan_disbursements`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sl_loan_guarantees`
--
ALTER TABLE `sl_loan_guarantees`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sl_loan_guarantors`
--
ALTER TABLE `sl_loan_guarantors`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sl_loan_payment_requests`
--
ALTER TABLE `sl_loan_payment_requests`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sl_loan_repayments`
--
ALTER TABLE `sl_loan_repayments`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sl_loan_types`
--
ALTER TABLE `sl_loan_types`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sl_members`
--
ALTER TABLE `sl_members`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sl_transactions`
--
ALTER TABLE `sl_transactions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `sl_vehicle_lease_contracts`
--
ALTER TABLE `sl_vehicle_lease_contracts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sl_vehicle_lease_payments`
--
ALTER TABLE `sl_vehicle_lease_payments`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `sl_client_accounts`
--
ALTER TABLE `sl_client_accounts`
  ADD CONSTRAINT `sl_client_accounts_member_fk` FOREIGN KEY (`member_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_client_accounts_type_fk` FOREIGN KEY (`account_type_id`) REFERENCES `sl_account_types` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_company_accounts`
--
ALTER TABLE `sl_company_accounts`
  ADD CONSTRAINT `sl_company_accounts_type_fk` FOREIGN KEY (`account_type_id`) REFERENCES `sl_account_types` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_expenses`
--
ALTER TABLE `sl_expenses`
  ADD CONSTRAINT `fk_expenses_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_expenses_category_fk` FOREIGN KEY (`category_id`) REFERENCES `sl_expense_categories` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_expenses_company_account_fk` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_incomes`
--
ALTER TABLE `sl_incomes`
  ADD CONSTRAINT `fk_incomes_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_incomes_category_fk` FOREIGN KEY (`category_id`) REFERENCES `sl_income_categories` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_incomes_company_account_fk` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_loans`
--
ALTER TABLE `sl_loans`
  ADD CONSTRAINT `fk_sl_loans_approved_by_auth_user` FOREIGN KEY (`approved_by_id`) REFERENCES `auth_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_loans_company_account_fk` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_loans_interest_type_fk` FOREIGN KEY (`interest_type_id`) REFERENCES `sl_interest_types` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_loans_loan_type_fk` FOREIGN KEY (`loan_type_id`) REFERENCES `sl_loan_types` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_loans_member_fk` FOREIGN KEY (`member_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_loan_disbursements`
--
ALTER TABLE `sl_loan_disbursements`
  ADD CONSTRAINT `sl_ld_company_account_fk` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_ld_loan_fk` FOREIGN KEY (`loan_id`) REFERENCES `sl_loans` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_ld_member_fk` FOREIGN KEY (`member_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_loan_guarantees`
--
ALTER TABLE `sl_loan_guarantees`
  ADD CONSTRAINT `sl_loan_guarantees_loan_fk` FOREIGN KEY (`loan_id`) REFERENCES `sl_loans` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_loan_guarantors`
--
ALTER TABLE `sl_loan_guarantors`
  ADD CONSTRAINT `sl_loan_guarantors_loan_fk` FOREIGN KEY (`loan_id`) REFERENCES `sl_loans` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_loan_guarantors_member_fk` FOREIGN KEY (`guarantor_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_loan_payment_requests`
--
ALTER TABLE `sl_loan_payment_requests`
  ADD CONSTRAINT `sl_lpr_company_account_fk` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_lpr_loan_fk` FOREIGN KEY (`loan_id`) REFERENCES `sl_loans` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_lpr_member_fk` FOREIGN KEY (`member_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_loan_repayments`
--
ALTER TABLE `sl_loan_repayments`
  ADD CONSTRAINT `fk_loanrepayment_companyaccount` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_loanrepayment_loan` FOREIGN KEY (`loan_id`) REFERENCES `sl_loans` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_loanrepayment_member` FOREIGN KEY (`member_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_members`
--
ALTER TABLE `sl_members`
  ADD CONSTRAINT `sl_members_manager_fk` FOREIGN KEY (`manager_id`) REFERENCES `auth_user` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_transactions`
--
ALTER TABLE `sl_transactions`
  ADD CONSTRAINT `fk_sl_transactions_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sl_transactions_company_account_fk` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_vehicle_lease_contracts`
--
ALTER TABLE `sl_vehicle_lease_contracts`
  ADD CONSTRAINT `fk_vlc_company_account` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_vlc_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_vlc_driver` FOREIGN KEY (`driver_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_vlc_leased_vehicle` FOREIGN KEY (`leased_vehicle_id`) REFERENCES `sl_leased_vehicles` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `sl_vehicle_lease_payments`
--
ALTER TABLE `sl_vehicle_lease_payments`
  ADD CONSTRAINT `fk_vlp_company_account` FOREIGN KEY (`company_account_id`) REFERENCES `sl_company_accounts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_vlp_contract` FOREIGN KEY (`contract_id`) REFERENCES `sl_vehicle_lease_contracts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_vlp_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_vlp_driver` FOREIGN KEY (`driver_id`) REFERENCES `sl_members` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
